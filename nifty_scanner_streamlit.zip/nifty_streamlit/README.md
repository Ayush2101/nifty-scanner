# 📊 Nifty Smallcap 250 Scanner

A live, daily-scanning web app for Nifty Smallcap 250 stocks.
Hosted free on Streamlit Cloud — no code needed to use it.

---

## Deploy in 5 minutes (free)

**Step 1** — Create a free GitHub account at github.com (if you don't have one)

**Step 2** — Create a new repository called `nifty-scanner`
- Click the `+` button → New repository
- Name it `nifty-scanner`, make it Public, click Create

**Step 3** — Upload these two files to the repository:
- `app.py`
- `requirements.txt`
- Click "uploading an existing file" link on the repo page

**Step 4** — Go to share.streamlit.io
- Sign in with your GitHub account
- Click "New app"
- Select your `nifty-scanner` repo
- Main file path: `app.py`
- Click "Deploy!"

**Step 5** — Wait ~2 minutes → Your app is live at:
`https://your-username-nifty-scanner-app-xxxx.streamlit.app`

---

## What you get

- Scans all ~200 Nifty Smallcap 250 stocks
- 5 tabs: Leading / Coincident / Big Movers / Neutral / All
- All indicators: RSI, MACD, Stochastic, MFI, OBV, CMF, Bollinger Bands, EMA
- 2D / 3D / 5D % move for every stock
- Click "Run Scan" any time to refresh with live data
- Accessible from phone or desktop

## Indicators explained

| Signal | What it means |
|---|---|
| VOL BUILD | Volume 1.3–2× average — quiet accumulation |
| OBV RISING | On-Balance Volume trending up — money flowing in |
| CMF TURNING | Chaikin Money Flow just crossed above zero |
| RSI OFF SOLD | RSI 30–55 and rising — coming off oversold |
| BB SQUEEZE 🔥 | Bollinger Bands very tight — big move imminent |
| STOCH CROSS | Stochastic crossed up from oversold (<35) |
| MFI RISING | Money Flow Index rising from low levels |
